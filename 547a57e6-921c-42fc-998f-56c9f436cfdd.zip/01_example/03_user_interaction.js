alert("Hello");

prompt("Waht is your name?");

const NAME = prompt("Waht is your name?");