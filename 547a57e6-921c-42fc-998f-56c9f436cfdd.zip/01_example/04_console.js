let a = 5,
    b = 6;

console.log(a, b);
console.error("ERROR!!!");