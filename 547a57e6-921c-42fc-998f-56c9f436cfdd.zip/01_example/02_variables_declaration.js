let number = 15;

let string = "vasya";

const CONSTANT = "value cant be changed";