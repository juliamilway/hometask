let a = 5,
    b = 6;

let c = a + b; // +, -, *, /

let d = 3 % 2;

let firstName = "vasya",
    lastName = "petrov";

let fullName = firstName + lastName;

let message = `youser full name is ${fullName}`;